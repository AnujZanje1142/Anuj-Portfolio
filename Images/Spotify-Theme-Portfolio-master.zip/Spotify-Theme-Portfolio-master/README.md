# Spotify Themed Portfolio
#### Made with vanilla javascript, html5 and css


## Currently working on a React version of this site
